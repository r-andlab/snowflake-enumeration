# Real-world data

Hourly aggregates derived from Tor Snowflake–related measurements: each row is one **UTC hour**

## Files

| File | Description |
|------|-------------|
| `restricted_with_country_with_rank.csv` | Restricted-network cohort, aggregated by hour. |
| `unrestricted_with_country_with_rank_with_type.csv` | Unrestricted cohort, aggregated by hour (filename reflects an earlier row-level export that included an IP “type” column). |

## CSV columns

Both files share the same schema:

| Column | Meaning |
|--------|---------|
| `hour` | Start of the hour in UTC (`YYYY-MM-DDTHH:00:00Z`). |
| `unique_hashes` | Count of distinct client IP hashes observed in that hour. |
| `unique_countries` | Count of distinct country codes among those observations. |
| `unique_asns` | Count of distinct AS numbers among those observations. |

